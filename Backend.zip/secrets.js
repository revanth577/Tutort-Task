 const db_url="mongodb://localhost:27017/mydb";


 exports.db_url=db_url
